CREATE VIEW "vehicles view" as
select * from vehicles;

