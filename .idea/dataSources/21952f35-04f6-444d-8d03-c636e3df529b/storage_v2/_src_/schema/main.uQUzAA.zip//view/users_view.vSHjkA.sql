CREATE VIEW "users view" as
select * from users;

