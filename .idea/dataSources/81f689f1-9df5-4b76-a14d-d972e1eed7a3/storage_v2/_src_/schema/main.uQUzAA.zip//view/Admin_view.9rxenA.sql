CREATE VIEW "Admin view" as
select * from admins;

